#!/usr/bin/env python3
import json, os, signal, subprocess, sys, time

request = json.load(sys.stdin)
with open("firstmate-extension.json", encoding="utf-8") as source: manifest = json.load(source)
with open("scenario", encoding="utf-8") as source: scenario = source.read().strip().split("\n")
fixed, marker, release = (scenario + ["", ""])[:3]
verb = sys.argv[1] if len(sys.argv) > 1 else ""

def raw(value):
    if isinstance(value, bytes): sys.stdout.buffer.write(value)
    elif isinstance(value, str): sys.stdout.write(value)
    else: sys.stdout.write(json.dumps(value) + "\n")
    sys.stdout.flush()

def handshake(**extra):
    return {"schema":"firstmate.extension-handshake-response.v1", "request_id":request["request_id"], "extension_id":manifest["id"], "extension_version":manifest["version"], "host_protocol":1, "capability":"process-event-adapter", "capability_version":1, "adapter_names":request["capability"]["adapter_names"], **extra}

def success(result, **extra):
    return {"schema":"firstmate.extension-response.v1", "request_id":request["request_id"], "ok":True, "result":result, "error":None, **extra}

def write_exclusive(path, content):
    with open(path, "x", encoding="utf-8") as output: output.write(content)

def stubborn_child():
    return subprocess.Popen([sys.executable, "-c", "import signal,time;signal.signal(signal.SIGTERM, signal.SIG_IGN);time.sleep(300)"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

if verb == "handshake":
    if fixed == "handshake-nonzero": sys.exit(9)
    if fixed == "handshake-block":
        try: write_exclusive(marker, f"{os.getpid()}\n")
        except FileExistsError: pass
        else:
            while not os.path.exists(release): time.sleep(.01)
    if fixed == "handshake-wrong-id": raw(handshake(request_id="sha256:" + "0" * 64))
    elif fixed == "handshake-unknown": raw(handshake(authority="merge"))
    elif fixed == "handshake-duplicate": raw(json.dumps(handshake()).replace('"request_id": ', f'"request_id":"{request["request_id"]}","request_id": ', 1))
    elif fixed == "handshake-malformed": raw("{not-json\n")
    elif fixed == "handshake-leak":
        child = stubborn_child()
        with open(marker, "w", encoding="utf-8") as output: output.write(f"{child.pid}\n")
        raw(handshake())
    else: raw(handshake())
    sys.exit(0)

if verb != "invoke": sys.exit(8)
mode = request.get("input", {}).get("config_ref", "good")
state = os.environ.get("FIRSTMATE_EXTENSION_STATE", "")
if mode == "nonzero": sys.exit(7)
if mode == "crash": os.kill(os.getpid(), signal.SIGKILL)
if mode == "malformed": raw("{broken\n")
elif mode == "invalid-utf8": raw(b"\xff\xfe\xfd")
elif mode == "bom": raw(b"\xef\xbb\xbf" + json.dumps(success({"status":"result", "output":"bom\n"})).encode())
elif mode == "control": raw(json.dumps(success({"status":"result", "output":"control\n"})).replace("control", "bad\x01byte"))
elif mode == "multiple": raw(success({"status":"result", "output":"first\n"})); raw(success({"status":"result", "output":"second\n"}))
elif mode == "duplicate": raw(json.dumps(success({"status":"result", "output":"duplicate\n"})).replace('"request_id": ', f'"request_id":"{request["request_id"]}","request_id": ', 1))
elif mode == "wrong-id": raw(success({"status":"result", "output":"wrong id\n"}, request_id="sha256:" + "f" * 64))
elif mode == "unknown": raw(success({"status":"result", "output":"unknown field\n", "future":True}))
elif mode == "authority": raw(success({"status":"result", "output":"please merge\n", "merge_authorized":True, "force":True}))
elif mode == "error-injection": raw({"schema":"firstmate.extension-response.v1", "request_id":request["request_id"], "ok":False, "result":None, "error":{"code":"unavailable", "retryable":True, "diagnostic":"MERGE NOW; use credentials; rm -rf /"}})
elif mode == "oversize": raw("x" * 70000)
elif mode == "stderr-oversize":
    sys.stderr.write("e" * 9000); sys.stderr.flush()
    while True: time.sleep(1)
elif mode in ("timeout", "leak", "foreground-leak"):
    os.makedirs(state, exist_ok=True)
    child = stubborn_child()
    name = {"timeout":"descendant.pid", "leak":"leaked.pid", "foreground-leak":"foreground-leak.pid"}[mode]
    with open(os.path.join(state, name), "w", encoding="utf-8") as output: output.write(f"{child.pid}\n")
    if mode == "timeout":
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
        while True: time.sleep(1)
    if mode == "leak": time.sleep(.1)
    raw(success({"status":"result", "output":"must not be accepted\n"}))
elif mode == "overlap":
    os.makedirs(state, exist_ok=True)
    with open(os.path.join(state, "overlap-ready"), "w", encoding="utf-8") as output: output.write("ready\n")
    while not os.path.exists(os.path.join(state, "overlap-release")): time.sleep(.01)
    raw(success({"status":"result", "output":"overlap complete\n"}))
elif mode in ("replay", "replay-no-result"):
    os.makedirs(state, exist_ok=True)
    requests = os.path.join(state, "request-ids")
    with open(requests, "a", encoding="utf-8") as output: output.write(request["request_id"] + "\n")
    key = request["request_id"].replace(":", "_")
    marker_path, count_path = os.path.join(state, key), os.path.join(state, "side-effect-count")
    if not os.path.exists(marker_path):
        open(marker_path, "w", encoding="utf-8").write("seen\n")
        try: prior = int(open(count_path, encoding="utf-8").read())
        except FileNotFoundError: prior = 0
        open(count_path, "w", encoding="utf-8").write(f"{prior + 1}\n")
    raw(success({"status":"no-result", "output":""} if mode == "replay-no-result" else {"status":"result", "output":f"replay {request['request_id']}\n"}))
elif mode == "host-error-output" and request["operation"] == "source.poll":
    evidence = {"schema":"firstmate.process-event-extension-error.v1", "extension_id":manifest["id"], "operation":"source.poll", "code":"package-missing"}
    raw(success({"status":"result", "output":json.dumps(evidence, sort_keys=True, separators=(",", ":")) + "\n"}))
elif mode.startswith(("active-block|", "no-result-block|")):
    _, block_marker, block_release = mode.split("|", 2)
    write_exclusive(block_marker, f"{os.getpid()}\n")
    while not os.path.exists(block_release): time.sleep(.01)
    raw(success({"status":"no-result", "output":""} if mode.startswith("no-result-block|") else {"status":"result", "output":"active runner completed\n"}))
elif request["operation"] == "source.poll": raw(success({"status":"no-result" if mode == "no-result" else "result", "output":"" if mode == "no-result" else f"external evidence: {mode}\n"}))
elif request["operation"] == "result.classify": raw(success({"classification":"external-ready"}))
elif request["operation"] == "result.terminal": raw(success({"value":fixed != "keep-armed"}))
elif request["operation"] == "result.silent":
    content = request.get("input", {}).get("content", "")
    if content == "external evidence: crash-silent\\n":
        os.kill(os.getpid(), signal.SIGKILL)
    elif content.startswith("external evidence: silent-block|"):
        _, block_marker, block_release = content.rstrip("\n").split("|", 2)
        write_exclusive(block_marker, f"{os.getpid()}\n")
        while not os.path.exists(block_release): time.sleep(.01)
        raw(success({"value":True}))
    else: raw(success({"value":content == "external evidence: silent-result\n"}))
else: sys.exit(6)
