printf ready > "$NESTED_SOURCE_READY"
while [ ! -e "$NESTED_SOURCE_RELEASE" ]; do sleep 0.01; done
exit 75
