perl -e 'print STDERR "nested-noise" x 131072 or exit 99' || exit 99
printf drained > "$NESTED_DRAINED"
