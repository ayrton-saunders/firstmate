if [ "${0##*/}" = fm-procevent.sh ] && [ "${1:-}" = _owner-watchdog ]; then
  printf '%s\n' "$$" > "$NESTED_GUARD_PID"
  printf 'nested guard stderr ready\n' >&2
  trap 'bash "$NESTED_NOISE_SCRIPT"' USR1
fi
